#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>

int main(){
    char str[11];
    printf("Input your String: \n");

    int i = 0;
    for(; i < 10; i++){
        char buf = getchar();
        str[i] = buf;
        if(buf == '\n')break;   
    }
    str[i] = '\0';
    printf("\n%s",str);

    printf("Datentypen Sizes: \n");
    printf("Character %d\n",sizeof(char));
    printf("Double %d\n",sizeof(double));
    printf("Unsigned Short %d\n",sizeof(unsigned short));
    printf("Long Long %d\n",sizeof(long long));
    printf("uint32_t %d\n",sizeof(unsigned __int32));
    printf("uint32_t %d\n",sizeof(unsigned __int64));
}