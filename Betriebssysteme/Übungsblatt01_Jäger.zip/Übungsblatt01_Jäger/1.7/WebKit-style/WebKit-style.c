#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <stdlib.h>
#include <time.h>

void printArray(char* fib, int startIndex)
{
    fib += startIndex;
    for (int i = startIndex; i < 8; i++) {
        printf("%d\n", *(fib++));
    }
}

int main()
{
    char fib[8];
    fib[0] = 0;
    fib[1] = 1;

    for (int i = 2; i <= 8; i++)
        fib[i] = fib[i - 1] + fib[i - 2];

    srand(time(NULL)); // Weil der Seed sonst immer gleich ist muss hier der Seed erneut festgelegt werden (Sekunden seit 1 Jänner 1970)
    int random = rand() % 8;
    printf("Index: %d\n", random);
    printArray(fib, random);
}
